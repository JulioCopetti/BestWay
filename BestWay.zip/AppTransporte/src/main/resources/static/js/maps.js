const longLatitude = [];
const mapeamento = [];
$(document).ready(() => {
    $('tr .longitude').each((i, el) => {
        longLatitude.push({lng: el.innerText});
    });
    $('tr .latitude').each((i, el) => {
        longLatitude[i].lat = el.innerText;
    });
    longLatitude.forEach((el) => {
        mapeamento.push(`${el.lat},${el.lng}`);
    });

});


function initMap() {
    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer;
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: {
            lat: -24.732916,
            lng: -53.739649
        }
    });
    directionsDisplay.setMap(map);

    $('.clickTable').on('click', () => {
        calculateAndDisplayRoute(directionsService, directionsDisplay);
    });
}
 initMap();
function calculateAndDisplayRoute(directionsService, directionsDisplay) {
    directionsService.route({
        origin: mapeamento[0],
        waypoints: [{
                location: mapeamento[1],
                stopover: true
            }],
        destination: mapeamento[2],
        travelMode: 'DRIVING'
    }, function (response, status) {
        if (status === 'OK') {
            directionsDisplay.setDirections(response);
        } else {
            alert('Directions request failed due to ' + status);
        }
    });
}