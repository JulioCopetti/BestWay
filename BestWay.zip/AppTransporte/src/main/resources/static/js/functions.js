$(document).ready(function ($) {
    $(".clickable-row").click(function () {
        window.location = $(this).data("href");
    });

});

$(".delete-plan-bt").on('click', deleteRow);
$('.capacidade').mask('00');
$('.cnpj').mask('00.000.000/0000-00');
$('.placa').mask('SSS-0000');
$('.chassi').mask('0SSSS00SS00000000');

const alerts = {
    empresa:`Exclua todos os veiculos primeiro`,
    rotas:`Exclua todos as paradas primeiro`,
    vans:`Exclua todos as rotas primeiro`,
    paradas:`Entra em contato com o julio que deu alguma merda nisso ai`
}

function deleteRow(event) {
    const button = $(event.target).parent();
    const codigoempresa = button.data('target');
    const rota = button.data('type');
    $.ajax(`${rota}/${codigoempresa}`, {
        type: "DELETE",
        error: () => {
            alert(alerts[rota]);
        }
    }).done(() => {
        button.closest("tr").remove();
    });
};