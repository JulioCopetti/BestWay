package br.unipar.appVan.rowmapper;

import br.unipar.appVan.pojo.Empresa;
import br.unipar.appVan.pojo.Veiculo;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author julio
 */
public class VeiculoRowMapper implements RowMapper<Veiculo>{

    @Override
    public Veiculo mapRow(ResultSet rs, int i) throws SQLException {
        
        Veiculo veiculo = new Veiculo();
        Empresa empresa = new Empresa();
        
        veiculo.setCodigo(rs.getLong("id_veiculo"));
        veiculo.setPlaca(rs.getString("placa"));
        veiculo.setChassi(rs.getString("chassi"));
        veiculo.setCapacidade(rs.getInt("capacidade"));
        veiculo.setCor(rs.getString("cor"));
        veiculo.setMarca(rs.getString("marca"));
        empresa.setCodigo(rs.getLong("id_empresa"));
        veiculo.setEmpresa(empresa);
        
        return veiculo;
    }
    
}
