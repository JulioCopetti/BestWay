package br.unipar.appVan.dao;

import br.unipar.appVan.rowmapper.RotaRowMapper;
import br.unipar.appVan.pojo.Rota;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 *
 * @author julio
 */
@Component
public class RotasDAO {

    @Autowired
    private JdbcTemplate template;


    public List<Rota> lista(Long codigo) {
        String sql = "SELECT * FROM rotas WHERE id_veiculo = ? ORDER BY id_rotas";

        Object[] parametros = {codigo};

        return template.query(sql, parametros, new RotaRowMapper());
    }
    
    public Rota buscaRota(Long i) {
        String sql = "SELECT * FROM rotas WHERE id_rotas = ? LIMIT 1";

        Object[] parametros = {i};

        return template.queryForObject(sql, parametros, new RotaRowMapper());
    }
    
    public void salvar(Rota rota) {
        String sql = "INSERT INTO rotas(id_veiculo,nm_rota) VALUES (?,?)";

        Object[] parametros = {
            rota.getVeiculo().getCodigo(),
            rota.getNomeRota(),
        };

        template.update(sql, parametros);
    }

    public void atualiza(Long codigo, Rota rota) {
        String sql = "UPDATE rotas SET nm_rota = ? WHERE id_rotas = ?";

        Object[] parametros = {
            rota.getNomeRota(),
            codigo
        };

        template.update(sql, parametros);
    }

    public void remove(Long codigo) {
        String sql = "DELETE FROM rotas WHERE id_rotas = ?";

        Object[] parametros = {codigo};

        template.update(sql, parametros);
    }
}
