package br.unipar.appVan.controladores;

import br.unipar.appVan.pojo.Empresa;
import br.unipar.appVan.pojo.Veiculo;
import br.unipar.appVan.dao.VeiculosDAO;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author julio
 */
@Controller
@RequestMapping({"/vans/{codigo}","/vans"})
public class VeiculoController {

    private Long codigoEmpresa;

    @Autowired
    private VeiculosDAO veiculoRepository;
    
    @GetMapping
    public String lista(@PathVariable("codigo") Long codigo, Model model) {
        this.codigoEmpresa = codigo;
        model.addAttribute("vans", veiculoRepository.listaVans(this.codigoEmpresa));
        model.addAttribute("page", "veiculo/lista");
        return "empresa/index_empresa";
    }

    @GetMapping({"/cadastro-vans", "/cadastro-vans/{codigo}"})
    public String CadastroVam(@PathVariable("codigo") Optional<Long> codigo, Model model) {
            if (codigo.isPresent()) {
            model.addAttribute("veiculo", veiculoRepository.buscaVam(codigo.get()));
        } else {
            model.addAttribute("veiculo", new Veiculo());
        }
        model.addAttribute("page", "veiculo/cadastro");
        return "empresa/index_empresa";
    }

    @PostMapping({"/cadastro-vans", "/cadastro-vans/{codigoVan}"})
    public String gravarVeiculo(@PathVariable("codigoVan") Optional<Long> codigo, Veiculo veiculo) {

        Empresa empresa = new Empresa();
        empresa.setCodigo(this.codigoEmpresa);
        veiculo.setEmpresa(empresa);

        if (codigo.isPresent()) {
            veiculoRepository.atualizaDadosVeiculo(codigo.get(), veiculo);
        } else {
            veiculoRepository.salvarVeiculo(veiculo);
        }

        return "redirect:/vans/" + this.codigoEmpresa;
    }

    @DeleteMapping("/{codigo}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteVeiculo(@PathVariable("codigo") Long codigo) {
        veiculoRepository.removeVeiculo(codigo);
    }

}
