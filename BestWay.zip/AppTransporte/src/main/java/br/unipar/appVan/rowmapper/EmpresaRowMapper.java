package br.unipar.appVan.rowmapper;

import br.unipar.appVan.pojo.Empresa;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author julio
 */
public class EmpresaRowMapper implements RowMapper<Empresa>{

    @Override
    public Empresa mapRow(ResultSet rs, int i) throws SQLException {
        
        Long codigo = rs.getLong("id_empresa");
        String nome = rs.getString("nm_empresa");
        String cnpj = rs.getString("cnpj");
        
        return new Empresa(codigo,nome,cnpj);
    }
    
}
