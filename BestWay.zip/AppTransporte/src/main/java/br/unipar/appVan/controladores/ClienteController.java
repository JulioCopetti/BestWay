package br.unipar.appVan.controladores;

import br.unipar.appVan.dao.ClienteDAO;
import br.unipar.appVan.dao.ParadaDAO;
import br.unipar.appVan.pojo.Parada;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cliente")
public class ClienteController {
        
    @Autowired
    private ClienteDAO clienteDAO;
    @Autowired
    private ParadaDAO paradaDAO;
    
    @GetMapping
    public String lista(Model model) {
        model.addAttribute("rotas", clienteDAO.ListaCompleta());
        model.addAttribute("page", "cliente/rotas");
        return "cliente/index_cliente";
    }
    @GetMapping("/paradas/{codigo}")
    public String listaParadas(@PathVariable("codigo") Long codigo, Model model) {
        model.addAttribute("paradas", paradaDAO.lista(codigo));
        model.addAttribute("page", "cliente/paradas");
        return "cliente/index_cliente";
    }
    @GetMapping("/paradas/maps-paradas/{codigo}")
    public List<Parada> JsonParadas(@PathVariable("codigo") Long codigo) {
        System.out.println(paradaDAO.lista(codigo));
        return paradaDAO.lista(codigo);
    }

}
