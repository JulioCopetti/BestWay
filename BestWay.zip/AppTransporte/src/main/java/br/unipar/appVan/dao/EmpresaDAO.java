package br.unipar.appVan.dao;

import br.unipar.appVan.rowmapper.EmpresaRowMapper;
import br.unipar.appVan.pojo.Empresa;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 *
 * @author julio
 */
@Component
public class EmpresaDAO {

    @Autowired
    private JdbcTemplate template;
    
    public List<Empresa> listaEmpresas() {
        String sql = "SELECT * FROM  empresas ";
        
        return template.query(sql, new EmpresaRowMapper());
    }
    
    public Empresa buscaEmpresa(Long codigo) {
        String sql = "SELECT * FROM empresas WHERE id_empresa = ?";
        
        Object[] parametros = { codigo };
        
        return template.queryForObject(sql, parametros, new EmpresaRowMapper());
    }
    
    public void salvaEmpresa(Empresa empresa) {
        String sql = "INSERT INTO empresas(nm_empresa,cnpj) VALUES (?,?)";
        
        Object[] parametros = {
          empresa.getNome(),
          empresa.getCnpj()
        };
        
        template.update(sql, parametros);
    }
    
    public void atualizaDadosEmpresa(Long codigo, Empresa empresa) {
        String sql = "UPDATE empresas SET cnpj = ?, nm_empresa = ? WHERE id_empresa = ?";
        
        Object[] parametros = {
            empresa.getCnpj(),
            empresa.getNome(),
            codigo
        };
        
        template.update(sql, parametros);
    }
    
    public void removeEmpresa(Long codigo) {
        String sql = "DELETE FROM empresas WHERE id_empresa = ?";
        Object[] parametros = { codigo };
        
        template.update(sql, parametros);
    }
    
}
