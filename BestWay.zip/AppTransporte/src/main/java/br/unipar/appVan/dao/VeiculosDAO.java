package br.unipar.appVan.dao;

import br.unipar.appVan.rowmapper.VeiculoRowMapper;
import br.unipar.appVan.pojo.Veiculo;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 *
 * @author julio
 */
@Component
public class VeiculosDAO {

    @Autowired
    private JdbcTemplate template;

    public List<Veiculo> listaVans(Long codigo) {
        String sql = "SELECT * FROM veiculos WHERE id_empresa = ? ";

        Object[] parametros = {codigo};

        return template.query(sql, parametros, new VeiculoRowMapper());
    }

    public Veiculo buscaVam(Long codigo) {
        String sql = "SELECT * FROM veiculos INNER JOIN empresas ON veiculos.id_empresa = empresas.id_empresa WHERE id_veiculo = ?";

        Object[] parametros = {codigo};

        return template.queryForObject(sql, parametros, new VeiculoRowMapper());
    }

    public void salvarVeiculo(Veiculo veiculo) {
        String sql = "INSERT INTO veiculos(id_empresa,placa,chassi,capacidade,cor,marca) VALUES (?,?,?,?,?,?)";

        Object[] parametros = {
            veiculo.getEmpresa().getCodigo(),
            veiculo.getPlaca(),
            veiculo.getChassi(),
            veiculo.getCapacidade(),
            veiculo.getCor(),
            veiculo.getMarca()
        };

        template.update(sql, parametros);
    }

    public void atualizaDadosVeiculo(Long codigo, Veiculo veiculo) {
        String sql = "UPDATE veiculos SET placa = ?, chassi = ?, capacidade = ?, cor = ?, marca = ? WHERE id_veiculo = ?";

        Object[] parametros = {
            veiculo.getPlaca(),
            veiculo.getChassi(),
            veiculo.getCapacidade(),
            veiculo.getCor(),
            veiculo.getMarca(),
            codigo
        };

        template.update(sql, parametros);
    }

    public void removeVeiculo(Long codigo) {
        String sql = "DELETE FROM veiculos WHERE id_veiculo = ?";

        Object[] parametros = {codigo};

        template.update(sql, parametros);
    }

}
