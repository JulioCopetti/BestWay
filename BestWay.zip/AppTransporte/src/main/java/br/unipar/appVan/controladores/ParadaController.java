package br.unipar.appVan.controladores;

import br.unipar.appVan.dao.ParadaDAO;
import br.unipar.appVan.pojo.Parada;
import br.unipar.appVan.pojo.Rota;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author julio
 */
@Controller
@RequestMapping({"/paradas/{codigo}", "/paradas"})
public class ParadaController {

    private Long codigo;

    @Autowired
    private ParadaDAO DAO;

    @GetMapping
    public String lista(@PathVariable("codigo") Long codigo, Model model) {
        this.codigo = codigo;
        model.addAttribute("paradas", DAO.lista(this.codigo));
        model.addAttribute("page", "parada/lista");
        return "empresa/index_empresa";
    }

    @GetMapping({"/cadastro-parada", "/cadastro-parada/{codigo}"})
    public String Cadastro(@PathVariable("codigo") Optional<Long> codigo, Model model) {
        if (codigo.isPresent()) {
            model.addAttribute("paradas", DAO.buscaRota(codigo.get()));
        } else {
            model.addAttribute("paradas", new Parada());
        }
        model.addAttribute("page", "parada/cadastro");
        return "empresa/index_empresa";
    }

    @PostMapping({"/cadastro-parada", "/cadastro-parada/{codigo}"})
    public String gravar(@PathVariable("codigo") Optional<Long> codigo, Parada parada) {

        Rota rota = new Rota();
        rota.setCodigo(this.codigo);
        parada.setRotas(rota);

        if (codigo.isPresent()) {
            DAO.atualiza(codigo.get(), parada);
        } else {
            DAO.salvar(parada);
        }

        return "redirect:/paradas/" + this.codigo;
    }

    @DeleteMapping("/{codigo}")
    @ResponseStatus(HttpStatus.OK)
    public void excluir(@PathVariable("codigo") Long codigo) {
        DAO.remove(codigo);
    }
}
