package br.unipar.appVan.dao;

import br.unipar.appVan.rowmapper.ParadaRowMapper;
import br.unipar.appVan.pojo.Parada;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 *
 * @author julio
 */
@Component
public class ParadaDAO {

    @Autowired
    private JdbcTemplate template;


    public List<Parada> lista(Long codigo) {
        String sql = "SELECT * FROM paradas WHERE id_rotas = ?";

        Object[] parametros = {codigo};

        return template.query(sql, parametros, new ParadaRowMapper());
    }
    
    public Parada buscaRota(Long i) {
        String sql = "SELECT * FROM paradas WHERE id_rota = ? LIMIT 1";

        Object[] parametros = {i};

        return template.queryForObject(sql, parametros, new ParadaRowMapper());
    }
    
    public void salvar(Parada parada) {
        String sql = "INSERT INTO paradas(id_rotas, nm_parada, latitude, longitude) VALUES (?,?,?,?)";

        Object[] parametros = {
            parada.getRotas().getCodigo(),
            parada.getNome(),
            parada.getLatitude(),
            parada.getLongitude(),
        };

        template.update(sql, parametros);
    }

    public void atualiza(Long codigo, Parada parada) {
        String sql = "UPDATE paradas SET nm_parada = ?, longitude = ?, latitude = ? WHERE id_rotas = ?";

        Object[] parametros = {
            parada.getNome(),
            parada.getLatitude(),
            parada.getLongitude(),
            codigo
        };

        template.update(sql, parametros);
    }

    public void remove(Long codigo) {
        String sql = "DELETE FROM paradas WHERE id_rota = ?";

        Object[] parametros = {codigo};

        template.update(sql, parametros);
    }
}
