package br.unipar.appVan.rowmapper;

import br.unipar.appVan.pojo.Parada;
import br.unipar.appVan.pojo.Rota;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author julio
 */
public class ParadaRowMapper implements RowMapper<Parada>{

    @Override
    public Parada mapRow(ResultSet rs, int i) throws SQLException {
        Parada parada = new Parada();
        Rota rota = new Rota();
        
        parada.setCodigo(rs.getLong("id_rota"));
        parada.setNome(rs.getString("nm_parada"));
        parada.setLatitude(rs.getString("latitude"));
        parada.setLongitude(rs.getString("longitude"));
        rota.setCodigo(rs.getLong("id_rotas"));
        parada.setRotas(rota);

        return new Parada(parada.getCodigo() ,parada.getNome(), parada.getLatitude(), parada.getLongitude(), parada.getRotas());
    }
    
}
