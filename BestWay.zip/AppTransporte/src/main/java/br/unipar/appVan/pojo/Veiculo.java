package br.unipar.appVan.pojo;

/**
 *
 * @author julio
 */
public class Veiculo {
    
    private Long codigo;
    private String placa;
    private Integer capacidade;
    private String cor;
    private String chassi;
    private String marca;
    private String modelo;
    private Empresa empresa;
    private Rota rotas;

    public Veiculo(Long codigo, String placa, Integer capacidade, String cor, String chassi, String marca, String modelo, Empresa empresa) {
        this.codigo = codigo;
        this.placa = placa;
        this.capacidade = capacidade;
        this.cor = cor;
        this.chassi = chassi;
        this.marca = marca;
        this.modelo = modelo;
        this.empresa = empresa;
    }

    public Veiculo() {

    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Integer getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(Integer capacidade) {
        this.capacidade = capacidade;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Rota getRotas() {
        return rotas;
    }

    public void setRotas(Rota rotas) {
        this.rotas = rotas;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    
    
}
