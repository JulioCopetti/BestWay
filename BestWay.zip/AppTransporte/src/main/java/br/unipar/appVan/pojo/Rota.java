package br.unipar.appVan.pojo;

/**
 *
 * @author julio
 */
public class Rota {

    private Long codigo;
    private String nomeRota;
    private Veiculo veiculo;
    private Empresa empresa;

    public Rota() {
    }

    public Rota(Long codigo, String nomeRota, Veiculo veiculo) {
        this.codigo = codigo;
        this.nomeRota = nomeRota;
        this.veiculo = veiculo;
    }

    public Rota(Long codigo, String nomeRota, Veiculo veiculo, Empresa empresa) {
        this.codigo = codigo;
        this.nomeRota = nomeRota;
        this.veiculo = veiculo;
        this.empresa = empresa;
    }
    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNomeRota() {
        return nomeRota;
    }

    public void setNomeRota(String nomeRota) {
        this.nomeRota = nomeRota;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
    

}
