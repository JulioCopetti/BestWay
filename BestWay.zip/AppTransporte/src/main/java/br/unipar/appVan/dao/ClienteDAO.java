package br.unipar.appVan.dao;

import br.unipar.appVan.rowmapper.ClienteRowMapper;
import br.unipar.appVan.pojo.Rota;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 *
 * @author julio
 */
@Component
public class ClienteDAO {

    @Autowired
    private JdbcTemplate template;

    public List<Rota> ListaCompleta() {
        String sql = "SELECT id_rotas , nm_rota, c.nm_empresa, b.id_veiculo, c.id_empresa "
                + "FROM rotas AS a "
                + "LEFT JOIN veiculos AS b ON a.id_veiculo = b.id_veiculo "
                + "LEFT JOIN empresas AS c ON b.id_empresa = c.id_empresa ";
        
        return template.query(sql, new ClienteRowMapper());
    }
    

}
