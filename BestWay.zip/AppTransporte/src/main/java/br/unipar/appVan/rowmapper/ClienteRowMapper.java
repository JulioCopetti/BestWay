package br.unipar.appVan.rowmapper;

import br.unipar.appVan.pojo.Empresa;
import br.unipar.appVan.pojo.Rota;
import br.unipar.appVan.pojo.Veiculo;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author julio
 */
public class ClienteRowMapper implements RowMapper<Rota>{

    @Override
    public Rota mapRow(ResultSet rs, int i) throws SQLException {
        
        Veiculo veiculo = new Veiculo();
        Empresa empresa =new Empresa();
        Rota rota = new Rota();
        
        rota.setCodigo(rs.getLong("id_rotas"));
        rota.setNomeRota(rs.getString("nm_rota"));
        empresa.setNome(rs.getString("nm_empresa"));
        empresa.setCodigo(rs.getLong("id_empresa"));
        rota.setEmpresa(empresa);
        veiculo.setCodigo(rs.getLong("id_veiculo"));
        rota.setVeiculo(veiculo);
        return rota;
    }
    
}
