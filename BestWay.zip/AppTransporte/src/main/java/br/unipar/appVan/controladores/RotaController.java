package br.unipar.appVan.controladores;

import br.unipar.appVan.pojo.Rota;
import br.unipar.appVan.pojo.Veiculo;
import br.unipar.appVan.dao.RotasDAO;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author julio
 */
@Controller
@RequestMapping({"/rotas/{codigo}","/rotas"})
public class RotaController {
    
    private Long codigoRota;
    
    @Autowired
    private RotasDAO rotasRepository;
    
    @GetMapping
    public String lista(@PathVariable("codigo") Long codigo, Model model) {
        this.codigoRota = codigo;
        model.addAttribute("rotas", rotasRepository.lista(this.codigoRota));
        model.addAttribute("page", "rota/lista");
        return "empresa/index_empresa";
    }

    @GetMapping({"/cadastro", "/cadastro/{codigo}"})
    public String Cadastro(@PathVariable("codigo") Optional<Long> codigo, Model model) {
        if (codigo.isPresent()) {
            model.addAttribute("rota", rotasRepository.buscaRota(codigo.get()));
        } else {
            model.addAttribute("rota", new Rota());
        }
        model.addAttribute("page", "rota/cadastro");
        return "empresa/index_empresa";
    }

    @PostMapping({"/cadastro", "/cadastro/{codigoVan}"})
    public String gravar(@PathVariable("codigoVan") Optional<Long> codigo, Rota rota) {

        Veiculo veiculo = new Veiculo();
        veiculo.setCodigo(this.codigoRota);
        rota.setVeiculo(veiculo);

        if (codigo.isPresent()) {
            rotasRepository.atualiza(codigo.get(), rota);
        } else {
            rotasRepository.salvar(rota);
        }

        return "redirect:/rotas/" + this.codigoRota;
    }

    @DeleteMapping("/{codigo}")
    @ResponseStatus(HttpStatus.OK)
    public void excluir(@PathVariable("codigo") Long codigo) {
        rotasRepository.remove(codigo);
    }
}
