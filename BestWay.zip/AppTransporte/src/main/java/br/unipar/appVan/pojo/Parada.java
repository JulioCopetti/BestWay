package br.unipar.appVan.pojo;

/**
 *
 * @author julio
 */
public class Parada {

    private Long codigo;
    private String nome;
    private String latitude;
    private String longitude;
    private Rota rotas;

    public Parada(Long codigo, String nome, String latitude, String longitude, Rota rotas) {
        this.codigo = codigo;
        this.nome = nome;
        this.latitude = latitude;
        this.longitude = longitude;
        this.rotas = rotas;
    }

    public Parada() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Rota getRotas() {
        return rotas;
    }

    public void setRotas(Rota rotas) {
        this.rotas = rotas;
    }

    
}
