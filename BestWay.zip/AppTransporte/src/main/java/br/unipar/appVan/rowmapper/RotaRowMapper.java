package br.unipar.appVan.rowmapper;

import br.unipar.appVan.pojo.Rota;
import br.unipar.appVan.pojo.Veiculo;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author julio
 */
public class RotaRowMapper implements RowMapper<Rota>{

    @Override
    public Rota mapRow(ResultSet rs, int i) throws SQLException {
        Veiculo veiculo = new Veiculo();
        Rota rota = new Rota();
        
        rota.setCodigo(rs.getLong("id_rotas"));
        rota.setNomeRota(rs.getString("nm_rota"));
        veiculo.setCodigo(rs.getLong("id_veiculo"));
        rota.setVeiculo(veiculo);
        
        return rota;
    }
    
}
